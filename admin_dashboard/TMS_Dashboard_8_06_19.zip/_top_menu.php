<div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light  border-bottom" style="background: white;color:rgb(0,0,51);">
        <button class="btn " id="menu-toggle" style="background: #fff;color:rgb(0,0,51);">&#9776;</button>

        

        
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0" >
            
            
            <li class="nav-item dropdown">

              <a  role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <span>&#11167;</span>
               <b style="color:rgb(0,0,51);"> UserName</b>
                
             </a>

              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Profile</a>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#changepassword">Change Password</a>
                
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#myModal">Logout</a>
              </div>
            </li>
          </ul>
        

        
      </nav>
   