 <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="border-right" id="sidebar-wrapper" >
      
      <div class="list-group list-group-flush">
        <a href="index4.php" class="list-group-item list-group-item-action " style="background: #fff; color:rgb(0,0,51);">Dashboard</a>
        
        <ul style="list-style-type: none; margin-top:15px; margin-bottom: 5px; margin-left: 0px;">
                     <li class="side-item dropdown">
                      
              <a class="side-link dropdown-toggle"  id="navbarDropdown"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:rgb(0,0,51);"> &#x1F4C1; &nbsp; Task
              </a>

              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="sidebarDropdown" >
                        <a class="dropdown-item" href="_add.php"> &#x2b; &nbsp;Add</a>
                  
                        <a class="dropdown-item" href="_edit.php">  &#x270E; &nbsp;Edit</a>     
                        <a class="dropdown-item" href="_view.php"> &#x1f441; &nbsp; View</a>
                     
                            
                    
                
              </div>
            </li>
        </ul>
        <div class="dropdown-divider"></div>
        
      </div>
    </div>
  
    
