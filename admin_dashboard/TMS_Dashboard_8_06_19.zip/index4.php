
<?php include('_header.php');?>
 <?php include('_top_menu.php');?>
 <?php include('_side_nav.php');?>

   <p>
     <h1 style="color:#fff; margin-top: 15%; margin-left: 30%;">
       <b>WELCOME</b>
     </h1>
   </p>
  
 <?php include('_footer.php');?>